import { type NextRequest } from 'next/server'
import { updateSession } from '@/services/auth/middleware'

export async function middleware(request: NextRequest) {
    console.log('Middleware triggered for request:', request.nextUrl.pathname)
  return await updateSession(request)
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * Feel free to modify this pattern to include more paths.
     */
    '/((?!_next/static|_next/image|favicon.ico|api/sign-up|api/forgot-password|api/sign-in|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}
