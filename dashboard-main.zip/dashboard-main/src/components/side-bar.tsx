'use client';

import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import Button from './ui/button';


const links = [{ href: '/', label: 'Profile' }];

type SidebarProps = {
  isOpen: boolean;
  onClose: () => void;
};

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const pathname = usePathname();
  const [isDesktop, setIsDesktop] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setIsDesktop(window.innerWidth >= 768);
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <>
      {!isDesktop && isOpen && (
        <div
          className="fixed inset-x-0 top-[64px] bottom-0 bg-black bg-opacity-10 z-60 md:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={`fixed top-16 md:top-0 left-0 w-64 bg-white md:pb-10 md:pl-10 md:pr-0 md:pt-20 p-6 md:z-40 z-60 h-[calc(100vh-4rem)] md:h-full md:relative transition-transform duration-300 flex flex-col items-center gap-4 ${
          !isOpen && !isDesktop ? '-translate-x-full md:translate-x-0' : 'translate-x-0'
        }`}
      >
        {links.map(({ href, label }) => (
          <Button
            key={href}
            href={href}
            onClick={onClose}
            variant={pathname === href ? 'primary' : 'link'}
          >
            {label}
          </Button>
        ))}

        <Button variant="disabled" disabled>
          Coming soon
        </Button>
      </aside>
    </>
  );
}
