// components/SidebarWrapper.tsx
'use client'

import Sidebar from "./side-bar"



export default function SidebarWrapper() {
  return (
    <div className="hidden md:block w-64 h-full">
      {/* No event handlers passed here — this is safe */}
      <Sidebar isOpen={true} onClose={() => {}} />
    </div>
  )
}
