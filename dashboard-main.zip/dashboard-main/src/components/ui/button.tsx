"use client";

import clsx from "clsx";
import Link from "next/link";
import type {
  ButtonHTMLAttributes,
  AnchorHTMLAttributes,
  ReactNode,
} from "react";
import { inter } from "../../app/fonts";

type Variant = "primary" | "disabled" | "link" | "danger";

type BaseProps = {
  variant?: Variant;
  className?: string;
  children: ReactNode;
};

// Props for <button>
type ButtonAsButton = BaseProps &
  Omit<ButtonHTMLAttributes<HTMLButtonElement>, "type"> & {
    href?: undefined;
    type?: "submit" | "reset" | "button";
  };

// Props for <a> + next/link
type ButtonAsLink = BaseProps &
  Omit<AnchorHTMLAttributes<HTMLAnchorElement>, "type"> & {
    href: string;
  };

type ButtonProps = ButtonAsButton | ButtonAsLink;

export default function Button(props: ButtonProps) {
  const { variant = "primary", className, children, ...rest } = props;

  const baseClass =
    "w-full text-center py-2 px-4 mt-2 rounded border transition-colors duration-200";

  const variantClass = clsx({
    "bg-[#5D2C87] text-white border-[#5D2C87] hover:opacity-90":
      variant === "primary" && !("disabled" in props && props.disabled),
    "text-gray-400 cursor-not-allowed border-gray-300 bg-gray-100":
      variant === "disabled" || ("disabled" in props && props.disabled),
    "text-[#5D2C87] hover:bg-[#D5DAEB] border-[#5D2C87] bg-transparent":
      variant === "link",
    "bg-[#CF090D] text-white hover:bg-[#b0080c] border-[#CF090D]":
      variant === "danger",
  });

  const combinedClass = clsx(baseClass, variantClass, className);

  // Render Link if href exists
  if ("href" in props) {
    const { href, ...anchorProps } = rest as ButtonAsLink;
    return (
      <Link href={href} className={combinedClass} {...anchorProps}>
        {children}
      </Link>
    );
  }

  // Render <button>
  const { type = "button", ...buttonProps } = rest as ButtonAsButton;
  return (
    <button
      type={type}
      className={clsx(combinedClass, inter.className)}
      {...buttonProps}
    >
      {children}
    </button>
  );
}
