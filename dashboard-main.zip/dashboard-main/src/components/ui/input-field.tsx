// components/InputField.tsx
'use client'

import { InputHTMLAttributes } from 'react'
import { UseFormRegisterReturn } from 'react-hook-form'

interface InputFieldProps extends InputHTMLAttributes<HTMLInputElement> {
  register: UseFormRegisterReturn
  error?: string
  className?: string
}

export default function InputField({ register, error, className, ...rest }: InputFieldProps) {
  const defaultClass =
    'p-3 rounded-lg w-full text-black bg-white focus:outline-none focus:ring-2 focus:ring-[#5D2C87] border border-transparent'

  const errorClass = error ? 'border-red-500' : ''

  return (
    <div>
      <input
        {...register}
        {...rest}
        className={
          className
            ? className // 👈 use the passed className only
            : `${defaultClass} ${errorClass}` // 👈 fallback to default if not passed
        }
      />
      {error && <p className="text-red-600 text-sm mt-1">{error}</p>}
    </div>
  )
}
