"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { MdMenu, MdClose } from "react-icons/md"; // Material Icons
import Sidebar from "./side-bar";
import Button from "./ui/button";
import { createClient } from "@/services/auth/client";

export default function Navbar() {
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const router = useRouter();

  // Check if mobile
  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <>
      <header className="bg-white shadow-md h-16 flex items-center md:justify-end justify-between px-4 md:px-6 relative z-50">
        {/* Mobile toggle button */}
        {isMobile && (
          <button
            onClick={() => setSidebarOpen((prev) => !prev)}
            className="text-[#5D2C87] p-2"
          >
            {isSidebarOpen ? <MdClose size={28} /> : <MdMenu size={28} />}
          </button>
        )}

        {/* Logout */}
        <div>
        <Button
          onClick={async () => {
            const client = await createClient();
            client.auth.signOut();
            router.push("/signup");
          }}
          variant="danger"
          className=" text-sm px-6 py-2"
        >
          Log out
        </Button>
        </div>
      </header>

      {/* Sidebar (mobile only) */}
      {isMobile && (
        <Sidebar isOpen={isSidebarOpen} onClose={() => setSidebarOpen(false)} />
      )}

      {/* Floating logo above the navbar */}
      <div className="absolute md:top-[10px] md:left-[80px] top-[20px] left-1/2 transform -translate-x-1/2 z-50">
        <div className="relative w-[80px] h-[80px] md:w-[100px] md:h-[100px]">
          <Image
            src="/logo.png"
            alt="AGH Logo"
            fill
            className="object-contain"
            sizes="(max-width: 768px) 80px, 100px"
            priority
          />
        </div>
      </div>
    </>
  );
}
