// components/ProfileForm.tsx
"use client";

import { useForm, SubmitHandler } from "react-hook-form";
import InputField from "./ui/input-field";
import Button from "./ui/button";
import { useEffect, useState } from "react";
import toast from "react-hot-toast";

type FormValues = {
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  zipCode: string;
};

export default function ProfileForm() {
  const [user, setUser] = useState<FormValues | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm<FormValues>({
    defaultValues: {
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      email: user?.email || "",
      phone: user?.phone || "",
      zipCode: user?.zipCode || "",
    },
  });

  const onSubmit: SubmitHandler<FormValues> = async (data) => {
    const response = await fetch("/api/user", {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const errorData = await response.json();
      toast.error(`Error: ${errorData.error || "An unknown error occurred"}`);
      return;
    }
    toast.success("Profile updated successfully!");
    getUser();
  };

  const getUser = async () => {
    const response = await fetch("/api/user");
    if (!response.ok) {
      throw new Error("Failed to fetch user data");
    }
    const {user: userData} = await response.json();
    setUser({
      email: userData.email,
      firstName: userData.firstName,
      lastName: userData.lastName,
      zipCode: userData.zipCode,
      phone: userData.phone || "",
    });
    setValue("firstName", userData.firstName);
    setValue("lastName", userData.lastName);
    setValue("email", userData.email);
    setValue("zipCode", userData.zipCode);
    setValue("phone", userData.phone || "");
  };

  useEffect(() => {
    getUser();
  }, [getUser]);

  return (
    <div className="w-full">
      <h1 className="text-3xl font-bold text-[#5D2C87] mb-6 sm:text-left text-center">
        Profile
      </h1>

      <form
        onSubmit={handleSubmit(onSubmit)}
        className="w-full grid grid-cols-1 md:grid-cols-2 gap-4"
      >
        <InputField
          placeholder="First name"
          register={register("firstName", {
            required: "First name is required",
          })}
          error={errors.firstName?.message}
        />

        <InputField
          placeholder="Last name"
          register={register("lastName", { required: "Last name is required" })}
          error={errors.lastName?.message}
        />

        {/* <InputField
          placeholder="Email"
          type="email"
          className="hidden"
          register={register("email", {
            required: "Email is required",
            pattern: {
              value: /^\S+@\S+$/,
              message: "Invalid email address",
            },
          })}
          error={errors.email?.message}
        /> */}

        <InputField
          placeholder="Phone"
          register={register("phone", {
            required: "Phone number is required",
            pattern: {
              value: /^\d{10}$/,
              message: "Invalid phone number",
            },
          })}
          error={errors.phone?.message}
        />

        <InputField
          placeholder="Zip code"
          register={register("zipCode", {
            required: "Zip code is required",
            pattern: {
              value: /^\d{5}(-\d{4})?$/,
              message: "Invalid zip code",
            },
          })}
          error={errors.zipCode?.message}
        />

        <div className="md:col-span-2 flex justify-center mt-4">
          <Button
            type="submit"
            variant="primary"
            className="font-semibold px-8 md:w-auto"
          >
            Update
          </Button>
        </div>
      </form>
    </div>
  );
}
