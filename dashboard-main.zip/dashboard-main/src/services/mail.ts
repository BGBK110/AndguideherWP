import nodemailer from 'nodemailer';

export interface MailOptions {
    to: string;
    subject: string;
    text?: string;
    html?: string;
}

class NodeMailService {
    private transporter: nodemailer.Transporter;

    constructor() {
        this.transporter = nodemailer.createTransport({
            host: process.env.NEXT_PUBLIC_SMTP_HOST,
            port: Number(process.env.NEXT_PUBLIC_SMTP_PORT) || 587,
            secure: false,
            auth: {
                user: process.env.NEXT_PUBLIC_SMTP_USER,
                pass: process.env.NEXT_PUBLIC_SMTP_PASS,
            },
        });
    }

    async sendMail(options: MailOptions): Promise<void> {
        await this.transporter.sendMail({
            from: process.env.NEXT_PUBLIC_SMTP_FROM || process.env.NEXT_PUBLIC_SMTP_USER,
            to: options.to,
            subject: options.subject,
            text: options.text,
            html: options.html,
        });
    }
}

export const mailService = new NodeMailService();