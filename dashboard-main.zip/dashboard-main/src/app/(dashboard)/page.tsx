import ProfileForm from "../../components/profile-form";

export default function ProfilePage() {
  return (
    <div className="flex-1 p-10 rounded-2xl w-full md:h-full bg-[#D5DAEB] overflow-y-auto">
      <div className="w-full h-full   bg-[#D5DAEB]  rounded-lg md:rounded-3xl">  
        <ProfileForm />
      </div>
    </div>
  );
}
