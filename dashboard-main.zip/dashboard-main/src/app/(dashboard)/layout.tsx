import Navbar from "@/components/navbar";
import SidebarWrapper from "@/components/side-bar-wrapper";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navbar />
      <div className="flex h-[calc(100vh-4rem)]">
        <SidebarWrapper />
        <main className="flex-1 md:px-10 px-6 pb-10 md:pt-10 pt-12 bg-white overflow-y-auto">
          {children}
        </main>
      </div>
    </>
  );
}
