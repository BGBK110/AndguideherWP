import { Toaster } from "react-hot-toast";
import "../../global.css";
import { roboto } from './fonts'


export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <Toaster />
      <body className={roboto.className}>{children}</body>
    </html>
  );
}
