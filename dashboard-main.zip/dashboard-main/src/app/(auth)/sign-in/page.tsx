"use client";

import Image from "next/image";
import { useForm, SubmitHandler } from "react-hook-form";
import { useRouter } from "next/navigation";
import InputField from "@/components/ui/input-field";
import Button from "@/components/ui/button";
import Link from "next/link";
import toast from "react-hot-toast";

type Inputs = {
  email: string;
  password: string;
};

export default function SignInPage() {
  const { register, handleSubmit, formState: {errors} } = useForm<Inputs>();
  const router = useRouter();

  const onSubmit: SubmitHandler<Inputs> = async (data) => {

    const response = await fetch("/api/sign-in", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    if(response.status === 400) {
      const errorData = await response.json();
      if(errorData.code === "invalid_credentials") {
        toast.error(`Invalid email or password`);
      } else {
        toast.error(`"An unknown error occurred`);
      }
    }
    const user = await response.json()
    console.log("Login:", user);
    router.push("/");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#D5DAEB] px-4 py-8">
      <div className="bg-white shadow-xl rounded-2xl overflow-hidden max-w-5xl w-full flex flex-col md:flex-row">
        {/* Left Side Image */}
        <div className="w-full md:w-1/2 p-6 bg-white flex justify-center items-center">
          <Image
            src="/signup.png"
            alt="Login Visual"
            width={800}
            height={600}
            className="object-contain rounded-l-2xl"
            priority
          />
        </div>

        {/* Right Side Form */}
        <div className="w-full md:w-1/2 md:p-16 p-6 flex flex-col justify-center">
          <h2 className="text-4xl font-bold text-center text-[#5D2C87] mb-6 tracking-wide">
            LOGIN
          </h2>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <InputField
              className="w-full p-3 border border-[#666666] rounded-lg text-black bg-white focus:outline-none focus:ring-2 focus:ring-[#5D2C87]"
              type="email"
              placeholder="Email"
              register={register("email", {
                required: "Email is required",
                pattern: {
                  value: /^\S+@\S+$/i,
                  message: "Invalid email address",
                },
              })}
              error={errors.email?.message}
            />

            <InputField
              className="w-full p-3 border border-[#666666] rounded-lg text-black bg-white focus:outline-none focus:ring-2 focus:ring-[#5D2C87]"
              type="password"
              placeholder="Password"
              register={register("password", { required: true })}
              
            />

            <div className="flex justify-end text-sm">
              <Link href="/forgot-password" className="text-[#1E7CE8] underline">
                Forgot password?
              </Link>
            </div>

            <Button
              type="submit"
              variant="primary"
              className="py-3 font-semibold"
            >
              Login to AGH Account
            </Button>

          </form>
        </div>
      </div>
    </div>
  );
}
