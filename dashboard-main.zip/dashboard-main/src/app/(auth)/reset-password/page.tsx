"use client";

import Image from "next/image";
import { useForm, SubmitHandler } from "react-hook-form";
import InputField from "@/components/ui/input-field";
import Button from "@/components/ui/button";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";

type Inputs = {
  password: string;
};

export default function ResetPasswordPage() {
  const { register, handleSubmit, formState: { errors }, } = useForm<Inputs>();
  const router = useRouter();

  const onSubmit: SubmitHandler<Inputs> = async (data) => {
    const response = await fetch("/api/reset-password", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });
    if (response.ok) {
     router.push('/')
    } else {
      const errorData = await response.json();
      toast.error(`Error: ${errorData.error || "An unknown error occurred"}`);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#D5DAEB] px-4 py-8">
      <div className="bg-white shadow-xl rounded-2xl overflow-hidden max-w-5xl w-full flex flex-col md:flex-row">
        {/* Left Side Image */}
        <div className="w-full md:w-1/2 p-6 bg-white flex justify-center items-center">
          <Image
            src="/signup.png"
            alt="Login Visual"
            width={800}
            height={600}
            className="object-contain rounded-l-2xl"
            priority
          />
        </div>

        {/* Right Side Form */}
        <div className="w-full md:w-1/2 md:p-16 p-6 flex flex-col justify-center">
          <h2 className="text-4xl font-bold text-center text-[#5D2C87] mb-6 tracking-wide">
            Reset Password
          </h2>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <InputField
              className="w-full p-3 border border-[#666666] rounded-lg text-black bg-white focus:outline-none focus:ring-2 focus:ring-[#5D2C87]"
              type="password"
              placeholder="New Password"
              register={register("password", {
                required: "Password is required",
                minLength: {
                  value: 8,
                  message: "Password must be at least 8 characters long",
                },
              })}
              error={errors.password?.message}
            />

            <Button
              type="submit"
              variant="primary"
              className="py-3 font-semibold"
            >
              Reset Password
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
