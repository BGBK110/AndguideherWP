import { createClient } from "@/services/auth/server";
import { NextResponse } from "next/server";

// Get current user
export async function POST(request: Request) {
  try {
    const { email } = await request.json();
    const supabaseClient = await createClient();
    await supabaseClient.auth.resetPasswordForEmail(email, {
      redirectTo: `${process.env.NEXT_PUBLIC_APP_URL}/reset-password`,
    });
    return NextResponse.json({ success: true, message: "Password reset email sent successfully" });
  } catch (e) {
    const errorMessage =
      e instanceof Error ? e.message : "An unknown error occurred";
    return NextResponse.json({ error: errorMessage }, { status: 400 });
  }
}