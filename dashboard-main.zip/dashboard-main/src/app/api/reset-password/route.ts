import { createClient } from "@/services/auth/server";
import { NextResponse } from "next/server";

// Get current user
export async function POST(request: Request) {
  try {
    const { password } = await request.json();
    const supabaseClient = await createClient();
    const {
      data: { user },
      error: userError,
    } = await supabaseClient.auth.getUser();

    if (userError) {
      return NextResponse.json({ error: userError.message }, { status: 400 });
    }
    const { error } = await supabaseClient.auth.updateUser({
      email: user!.email,
      password,
    });

    if (error) {
      return NextResponse.json({ error: error }, { status: 400 });
    }
    return NextResponse.json({
      success: true,
      message: "Password reset successfully",
    });
  } catch (e) {
    const errorMessage =
      e instanceof Error ? e.message : "An unknown error occurred";
    return NextResponse.json({ error: errorMessage }, { status: 400 });
  }
}
