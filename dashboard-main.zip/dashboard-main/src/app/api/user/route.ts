import { createClient } from "@/services/auth/server";
import { NextResponse } from "next/server";
import mailChamp from "@mailchimp/mailchimp_marketing";
import crypto from "crypto";

// Get current user
export async function GET() {
  try {
    mailChamp.setConfig({
      apiKey: process.env.NEXT_PUBLIC_MAILCHAMP_API_KEY || "",
      server: process.env.NEXT_PUBLIC_SERVER_PREFIX || "",
    });

    const supabaseClient = await createClient();
    const {
      data: { user },
      error,
    } = await supabaseClient.auth.getUser();
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json({ user: user?.user_metadata || {} });
  } catch (e) {
    const errorMessage =
      e instanceof Error ? e.message : "An unknown error occurred";
    return NextResponse.json({ error: errorMessage }, { status: 400 });
  }
}

// Update user
export async function PUT(request: Request) {
  const body = await request.json();

  mailChamp.setConfig({
    apiKey: process.env.NEXT_PUBLIC_MAILCHAMP_API_KEY || "",
    server: process.env.NEXT_PUBLIC_SERVER_PREFIX || "",
  });

  try {
    const supabaseClient = await createClient();
    const {
      data: { user },
      error: userError,
    } = await supabaseClient.auth.getUser();

    if (userError) {
      return NextResponse.json({ error: userError.message }, { status: 400 });
    }
    const { data, error } = await supabaseClient.auth.updateUser({
      email: user!.email,
      data: body,
    });

    if (error) {
      return NextResponse.json({ error: error }, { status: 400 });
    }

    const userHash = crypto
      .createHash("md5")
      .update(body.email.toLowerCase())
      .digest("hex");
    await mailChamp.lists.updateListMember(
      process.env.NEXT_PUBLIC_MAILCHAMP_LIST_ID!,
      userHash,
      {
        merge_fields: {
          FNAME: body.firstName,
          LNAME: body.lastName,
          ZIP: body.zipCode,
          PHONE: body.phone || "",
        },
      }
    );

    return NextResponse.json(data);
  } catch (e) {
    const errorMessage =
      e instanceof Error ? e.message : "An unknown error occurred";
    return NextResponse.json({ error: errorMessage }, { status: 400 });
  }
}
