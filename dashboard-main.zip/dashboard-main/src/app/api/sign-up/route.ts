import { createClient } from "@/services/auth/server";
import { NextResponse } from "next/server";
import { mailService } from "@/services/mail";
import mailChimp from "@mailchimp/mailchimp_marketing";

export async function OPTIONS() {
  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': 'https://andguideher.com',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}

export async function POST(request: Request) {
  try {
    mailChimp.setConfig({
      apiKey: process.env.NEXT_PUBLIC_MAILCHAMP_API_KEY || "",
      server: process.env.NEXT_PUBLIC_SERVER_PREFIX || "",
    });

    // Read the raw request body as text
    const { email, firstName, lastName, address, phone, zipCode } =
      await request.json();

    // Generate a temporary password (consider better alternatives)
    const randomPassword = Math.random().toString(36).substring(2, 10);

    const supabaseClient = await createClient();

    const { data: user, error: signUpError } = await supabaseClient.auth.signUp(
      {
        email: email,
        password: randomPassword,
        options: {
          data: {
            email_verified: true,
            firstName: firstName,
            lastName: lastName,
            address: address,
            phone: phone,
            zipCode: zipCode,
          },
        },
      }
    );

    if (signUpError) {
      console.error("Error signing up user in Supabase:", signUpError.message);
      return NextResponse.json({ error: signUpError.message }, { status: 404 });
    }


    let mailchimpResponse;
    try {
      mailchimpResponse = await mailChimp.lists.addListMember(
        process.env.NEXT_PUBLIC_MAILCHAMP_LIST_ID!,
        {
          email_address: email,
          status: "subscribed", // "subscribed", "unsubscribed", "cleaned", "pending"
          merge_fields: {
            FNAME: firstName,
            LNAME: lastName,
            ADDRESS: address,
            PHONE: phone || "",
            ZIP_CODE: zipCode || "",
          },
        }
      );
      console.log("User added to Mailchimp:", JSON.stringify(mailchimpResponse));
    } catch (mailchimpError: unknown) {
      // Log the full error object and response body if available
      console.error("Mailchimp error:", mailchimpError);
      let errorDetails = mailchimpError;
      if (
        mailchimpError &&
        typeof mailchimpError === 'object' &&
        'response' in mailchimpError &&
        mailchimpError.response &&
        typeof mailchimpError.response === 'object' &&
        'body' in mailchimpError.response
      ) {
        const responseBody = (mailchimpError.response as { body?: unknown }).body;
        errorDetails = typeof responseBody === 'string'
          ? responseBody
          : JSON.stringify(responseBody);
      }
      return NextResponse.json(
        { error: "Mailchimp error", details: errorDetails },
        { status: 400 }
      );
    }

    await mailService.sendMail({
      to: email,
      subject: "Welcome to AGH!",
      html: `
          <div style="font-family: Arial, sans-serif; color: #222;">
        <h2>Welcome to AGH!</h2>
        <p>Dear ${firstName || ""} ${lastName || ""},</p>
        <p>
          Thank you for joining AGH!<br>
          <strong>Email:</strong> ${email}<br>
          <strong>Password:</strong> ${randomPassword}
        </p>
        <p>
          We’re thrilled you’ve taken the first step on our new path to improving and uniting our country. 
          AGH is about more than just standing with our nation, it’s about actively guiding her toward a better future. 
          Together, we can create meaningful impact and change our nation’s trajectory for the better.
        </p>
        <p>
          We’ll keep you informed about upcoming steps and let you know when the AGH platform becomes available in your area.
        </p>
        <p>
          Stay connected with us on <a href="https://twitter.com/AGHforUS" target="_blank">@AGHforUS</a><br>
          Interested in contributing further? Reach out to us at <a href="mailto:contact@andguideher.com">contact@andguideher.com</a>.
        </p>
        <p>
          You can log in to your account here: 
          <a href="https://app.andguideher.com/sign-in" target="_blank">Sign In</a>
        </p>
        <p>We’ll be in touch again soon!</p>
        <p>Sincerely,<br>AGH Team</p>
          </div>
        `,
    });

    console.log("User created", user);

    return NextResponse.json(
      { received: true },
      {
        status: 200,
        headers: {
          "Access-Control-Allow-Origin":
            "https://andguideher.com",
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error processing webhook:", error);
    return NextResponse.json(
      { error: "Failed to process webhook" },
      { status: 500 }
    );
  }
}
